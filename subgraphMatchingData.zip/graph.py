import numpy as np

g = open('hprd.gfu', 'r')
new_g = open('hprd.graph', 'w')
i = []
while True:
    line = g.readline()
    sp = line.split(" ")
    if not line: break
    i.append(sp)
g.close()
N = len(i)
n = int(i[1][0][0:-1])
m = 0
graph_format = []
graph_format.append(["t",n,0])
print(i[2])
print(i[3])
print(i[4])
for x in range(n):
    graph_format.append(["v", x, int(i[x+2][0]), 0])
print(i[n+2])
graph_format[0][2] = int(i[n+2][0][0:-1])
print(graph_format[0])
for x in range(n+3, N):
    #print(i[x])
    v1 = int(i[x][0])
    v2 = int(i[x][1][0:-1])
    graph_format[v1+1][3] +=1
    graph_format[v2+1][3] +=1
    graph_format.append(["e", v1, v2])

for a in graph_format:
    string = a[0]+" "+str(a[1])+" "+str(a[2])
    if len(a) == 3:
        string = string+"\n"
    else:
        string = string+" "+str(a[3])+"\n"
    
    new_g.write(string)
    
new_g.close()
        
